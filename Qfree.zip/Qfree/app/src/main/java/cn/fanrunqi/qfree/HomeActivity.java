package cn.fanrunqi.qfree;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class HomeActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
String details="",uid="",uname="",email="",ip="",res="";
    Fragment fragment = null;
    SharedPreferences sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        sp=getSharedPreferences("qfree", Context.MODE_PRIVATE);
        if (sp.contains("ip"))
        {
            ip=sp.getString("ip", "");
        }

        details=getIntent().getStringExtra("result");
        try {
            JSONArray jarray=new JSONArray(details);
            for(int i=0;i<jarray.length();i++){
                JSONObject json_data=jarray.getJSONObject(i);

               uname=json_data.getString("name");
                email=json_data.getString("email");
                uid=json_data.getString("id");

            }
        } catch (Exception e) {        // TODO Auto-generated catch block
            e.printStackTrace();
        }
        SharedPreferences.Editor editor = sp.edit();
        editor.putString("uid", uid);
        editor.commit();
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        View hView =  navigationView.getHeaderView(0);
        TextView nav_user = (TextView)hView.findViewById(R.id.txtuser);
        TextView nav_uemail = (TextView)hView.findViewById(R.id.txtemail);
        //  Toast.makeText(getApplicationContext(),image, Toast.LENGTH_LONG).show();
        String ur="http://192.168.43.13/Qfree_2017/uploads/user.png";
        // Toast.makeText(getApplicationContext(),ur, Toast.LENGTH_LONG).show();
       /* new DownloadImageTask((ImageView)hView.findViewById(R.id.imageView))
                .execute(ur);
*/
        nav_user.setText(uname);
        nav_uemail.setText(email);
        card();
       // displaySelectedScreen(R.id.nav_profile);
    }

    private void displaySelectedScreen(int itemId) {

        //creating fragment object

        // Toast.makeText(getApplicationContext(),"ghfhg"+details, Toast.LENGTH_LONG).show();
        //initializing the fragment object which is selected
        switch (itemId) {
            case R.id.nav_profile:
                //  Toast.makeText(getApplicationContext(),itemId, Toast.LENGTH_LONG).show();
                /*fragment = new ProfileFragment();
                Bundle bundle=new Bundle();
                bundle.putString("details", details);
                fragment.setArguments(bundle);*/
                Intent i=new Intent(HomeActivity.this,ProfActivity.class);
                i.putExtra("details",details);
                startActivity(i);

                break;
            case R.id.nav_purchase:
                fragment = new PurchaseFragment();

                break;
          case R.id.nav_cart:
                fragment = new CartFragment();
                break;
            case R.id.nav_history:
                fragment = new HistoryFragment();
                break;
            case R.id.nav_payment:
                fragment = new PaymentFragment();

                break;
            case R.id.nav_offers:
                fragment = new OfferFragment();
                Bundle bundle1=new Bundle();
                bundle1.putString("details",""+res);
                fragment.setArguments(bundle1);
                break;

        }

        //replacing the fragment
        if (fragment != null) {
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.content_frame, fragment);
            ft.commit();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Intent i=new Intent(HomeActivity.this,MainActivity.class);

            startActivity(i);

        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();


        displaySelectedScreen(id);
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
    public void card() {
        String UrlData = "?cno=" + "" ;
        // Toast.makeText(getApplicationContext(), UrlData, Toast.LENGTH_LONG).show();


        class RegisterUser extends AsyncTask<String, Void, String> {


            ProgressDialog progressDialog;


            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog = ProgressDialog.show(HomeActivity.this, "Please wait", null, true, true);


            }

            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                progressDialog.dismiss();
               // Toast.makeText(getApplicationContext(), s, Toast.LENGTH_LONG).show();
               // Log.d("hist",s);
                if(s!=null && s.equalsIgnoreCase("failed")){
                    // Toast.makeText(getApplicationContext(),"Invalid User", Toast.LENGTH_LONG).show();
                    displaySelectedScreen(R.id.nav_profile);
                }
                else {
                    res=s;
                    displaySelectedScreen(R.id.nav_offers);

                }



            }

            @Override
            protected String doInBackground(String... params) {

                String s = params[0];
                Log.d("result",params[0]);
                BufferedReader bf = null;

                try {
                    URL url = new URL("http://"+ip+"/Qfree_2017/get_offer.php" + s);

                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    bf = new BufferedReader(new InputStreamReader(connection.getInputStream()));


                    String result = bf.readLine();
                    return result;



                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }



            }

        }


        RegisterUser registerUser = new RegisterUser();
        registerUser.execute(UrlData);


    }


}
