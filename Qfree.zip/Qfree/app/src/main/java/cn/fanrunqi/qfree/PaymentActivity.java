package cn.fanrunqi.qfree;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class PaymentActivity extends AppCompatActivity {
EditText eacc,eamount;
String  acc="",am="",ip="",uid="";
    Button bpayment;
    SharedPreferences sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        sp =getSharedPreferences("qfree", Context.MODE_PRIVATE);
        if (sp.contains("ip"))
        {
            ip=sp.getString("ip", "");


        }
        if (sp.contains("uid"))
        {
            uid=sp.getString("uid", "");


        }
        eacc=(EditText)findViewById(R.id.edacc);
        eamount=(EditText) findViewById(R.id.edamount);
        bpayment=(Button)findViewById(R.id.bp);

        am=getIntent().getStringExtra("total");
        eamount.setText(""+am);
bpayment.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
     //   alert();
        String acc=eacc.getText().toString();
        String am=eamount.getText().toString();
        //pay(uid,acc,am);
        Intent i=new Intent(PaymentActivity.this,PinActivity.class);
        i.putExtra("total",am);
        i.putExtra("acc",acc);
        startActivity(i);
    }
});

        }

    ////////////////getCart///////////////////////////////////////////////////////
    public void pay( String uid,String acc,String amount) {

        String UrlData = "?uid=" + uid +"&acc="+acc+"&am="+amount;

        Log.d("url",""+UrlData);


        class PayDetails extends AsyncTask<String, Void, String> {


            ProgressDialog progressDialog;


            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog = ProgressDialog.show(PaymentActivity.this, "Please wait", null, true, true);


            }

            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                progressDialog.dismiss();
                //  Toast.makeText(getActivity(), s, Toast.LENGTH_LONG).show();
                if(s!=null && s.equalsIgnoreCase("failed")){
                    Toast.makeText(PaymentActivity.this,"Your Account Does not have Enough Balance", Toast.LENGTH_LONG).show();
                }
                else if(s!=null && s.equalsIgnoreCase("accerror")){
                    Toast.makeText(PaymentActivity.this,"Account Does exist", Toast.LENGTH_LONG).show();
                }
                else {
                    Toast.makeText(PaymentActivity.this,"Payment Success", Toast.LENGTH_LONG).show();
//
                }

            }

            @Override
            protected String doInBackground(String... params) {

                String s = params[0];
                Log.d("result",params[0]);
                BufferedReader bf = null;

                try {
                    URL url = new URL("http://"+ip+"/Qfree_2017/pay.php" + s);

                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    bf = new BufferedReader(new InputStreamReader(connection.getInputStream()));


                    String result = bf.readLine();
                    return result;



                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }



            }

        }


        PayDetails p = new PayDetails();
        p.execute(UrlData);


    }
}
