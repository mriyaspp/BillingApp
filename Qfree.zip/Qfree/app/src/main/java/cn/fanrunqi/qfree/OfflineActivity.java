package cn.fanrunqi.qfree;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

public class OfflineActivity extends AppCompatActivity {
    SharedPreferences sp;
    String uid="",ip="",pname="",price="",id="",qty="",acc,am,billno,statuss;
    int total;
    ListView listb;
    ArrayList<HashMap<String, String>> pdtlist;
    //SharedPreferences sp;
    TextView tot,bill,status,sta;
    Button st;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_offline);
        sp = getSharedPreferences("qfree", Context.MODE_PRIVATE);
        if (sp.contains("ip"))
        {
            ip=sp.getString("ip", "");


        }
        if (sp.contains("uid"))
        {
            uid=sp.getString("uid", "");


        }
        listb=(ListView)findViewById(R.id.listcartpay);
        tot=(TextView)findViewById(R.id.total);
        bill=(TextView)findViewById(R.id.bill);
        sta=(TextView)findViewById(R.id.stat);
        status=(Button)findViewById(R.id.st);
        pdtlist=new ArrayList<HashMap<String,String>>();
        status.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                getbillstatus(uid);
            }
        });
        getbillno(uid);
    getbill(uid);

    }
    public void showlist(String res){
        Log.d("res", res);
        JSONArray jarray = null;
        try {
            jarray = new JSONArray(res);

            for (int i = 0; i < jarray.length(); i++) {
                JSONObject jobj = null;

                jobj = jarray.getJSONObject(i);


                pname = jobj.getString("pname");
                price = jobj.getString("price");
                qty = jobj.getString("qty");
                id = jobj.getString("pid");
                total+=Integer.parseInt(price);


                HashMap<String, String> hist= new HashMap<String, String>();

                hist.put("pname", pname);
                hist.put("price", price);
                hist.put("qty", qty);
                hist.put("id", id);


                pdtlist.add(hist);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        ListAdapter adapter = new SimpleAdapter(OfflineActivity.this, pdtlist, R.layout.offlinebill, new String[]{"pname","qty", "price"}, new int[]{R.id.tpitem,R.id.tqty, R.id.tpprice});


        listb.setAdapter(adapter);
        tot.setText(""+total);

    }
    public void showbillno(String res){
        Log.d("res", res);
        JSONArray jarray = null;
        try {
            jarray = new JSONArray(res);

            for (int i = 0; i < jarray.length(); i++) {
                JSONObject jobj = null;

                jobj = jarray.getJSONObject(i);


                billno= jobj.getString("bill");
                statuss= jobj.getString("status");
                //Toast.makeText(OfflineActivity.this,billno, Toast.LENGTH_LONG).show();
                            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

       // ListAdapter adapter = new SimpleAdapter(OfflineActivity.this, pdtlist, R.layout.offlinebill, new String[]{"pname","qty", "price"}, new int[]{R.id.tpitem,R.id.tqty, R.id.tpprice});


       // listb.setAdapter(adapter);
        bill.setText("Billno        "+billno);
        sta.setText("Status         "+statuss);


    }

    public void getbill(String uid){
String uid1=uid;

        String UrlData = "?uid=" + uid1 ;

        Log.d("url",""+UrlData);


        class OfflineDetails extends AsyncTask<String, Void, String> {


            ProgressDialog progressDialog;


            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog = ProgressDialog.show(OfflineActivity.this, "Please wait", null, true, true);


            }

            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                progressDialog.dismiss();
                //Toast.makeText(OfflineActivity.this,s, Toast.LENGTH_LONG).show();
                //  Toast.makeText(getActivity(), s, Toast.LENGTH_LONG).show();
                if(s!=null && s.equalsIgnoreCase("failed")){
                    Toast.makeText(OfflineActivity.this,"No product In cart", Toast.LENGTH_LONG).show();
                }
                else {
                    showlist(s);
//
                }

            }

            @Override
            protected String doInBackground(String... params) {

                String s = params[0];
                Log.d("result",params[0]);
                BufferedReader bf = null;

                try {
                    URL url = new URL("http://"+ip+"/Qfree_2017/billoff.php" + s);

                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    bf = new BufferedReader(new InputStreamReader(connection.getInputStream()));


                    String result = bf.readLine();
                    return result;



                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }



            }

        }


        OfflineDetails cd = new OfflineDetails();
        cd.execute(UrlData);

    }
    public void getbillstatus(String uid){
String uid1=uid;
        Toast.makeText(OfflineActivity.this,uid1, Toast.LENGTH_LONG).show();

        String UrlData = "?uid=" + uid1 ;

        Log.d("url",""+UrlData);


        class OfflineDetails1 extends AsyncTask<String, Void, String> {


            ProgressDialog progressDialog;


            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog = ProgressDialog.show(OfflineActivity.this, "Please wait", null, true, true);


            }

            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                progressDialog.dismiss();
                //Toast.makeText(OfflineActivity.this,s, Toast.LENGTH_LONG).show();
                //  Toast.makeText(getActivity(), s, Toast.LENGTH_LONG).show();
                if(s!=null && s.equalsIgnoreCase("failed")){
                    Toast.makeText(OfflineActivity.this,"No product In cart", Toast.LENGTH_LONG).show();
                }
                else {
                    showbillno(s);
//
                }

            }

            @Override
            protected String doInBackground(String... params) {

                String s = params[0];
                Log.d("result",params[0]);
                BufferedReader bf = null;

                try {
                    URL url = new URL("http://"+ip+"/Qfree_2017/billstatus.php" + s);

                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    bf = new BufferedReader(new InputStreamReader(connection.getInputStream()));


                    String result = bf.readLine();
                    return result;



                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }



            }

        }


        OfflineDetails1 cd = new OfflineDetails1();
        cd.execute(UrlData);

    }
    public void getbillno(String uid){
String uid1=uid;

        String UrlData = "?uid=" + uid1 ;

        Log.d("url",""+UrlData);


        class OfflinebillDetails extends AsyncTask<String, Void, String> {


            ProgressDialog progressDialog;


            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog = ProgressDialog.show(OfflineActivity.this, "Please wait", null, true, true);


            }

            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                progressDialog.dismiss();
                //Toast.makeText(OfflineActivity.this,s, Toast.LENGTH_LONG).show();
                //  Toast.makeText(getActivity(), s, Toast.LENGTH_LONG).show();
                if(s!=null && s.equalsIgnoreCase("failed")){
                    Toast.makeText(OfflineActivity.this,"No product In cart", Toast.LENGTH_LONG).show();
                }
                else {
                    showbillno(s);
//
                }

            }

            @Override
            protected String doInBackground(String... params) {

                String s = params[0];
                Log.d("result",params[0]);
                BufferedReader bf = null;

                try {
                    URL url = new URL("http://"+ip+"/Qfree_2017/billnooff.php" + s);

                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    bf = new BufferedReader(new InputStreamReader(connection.getInputStream()));


                    String result = bf.readLine();
                    return result;



                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }



            }

        }


        OfflinebillDetails cd = new OfflinebillDetails();
        cd.execute(UrlData);

    }



}
