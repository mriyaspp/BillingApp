package cn.fanrunqi.qfree;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

public class PaymentoffActivity extends AppCompatActivity {
    SharedPreferences sp;
    String uid="",ip="",pname="",price="",id="",qty="",acc,am,billno,status;
    int total;
    ListView listb;
    ArrayList<HashMap<String, String>> pdtlist;
    private final String TAG="PaymentoffActivity";
    //SharedPreferences sp;
    TextView tot,bill,sta;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_paymentoff);
        sp = getSharedPreferences("qfree", Context.MODE_PRIVATE);
        if (sp.contains("ip"))
        {
            ip=sp.getString("ip", "");


        }
        if (sp.contains("uid"))
        {
            uid=sp.getString("uid", "");


        }
        listb=(ListView)findViewById(R.id.listcartpay);
        tot=(TextView)findViewById(R.id.total);
        bill=(TextView)findViewById(R.id.bill);
        sta=(TextView)findViewById(R.id.status1);
        // bp=(Button) root_view.findViewById(R.id.bpay);2
        pdtlist=new ArrayList<HashMap<String,String>>();

        am=getIntent().getStringExtra("total");
        acc=getIntent().getStringExtra("acc");
        getbillid(uid);
        getbill(uid);




    }
    public void showlist(String res){
        Log.d("res", res);
        JSONArray jarray = null;
        try {
            jarray = new JSONArray(res);

            for (int i = 0; i < jarray.length(); i++) {
                JSONObject jobj = null;

                jobj = jarray.getJSONObject(i);


                pname = jobj.getString("pname");
                price = jobj.getString("price");
                qty = jobj.getString("qty");
                id = jobj.getString("pid");
                total+=Integer.parseInt(price);


                HashMap<String, String> hist= new HashMap<String, String>();

                hist.put("pname", pname);
                hist.put("price", price);
                hist.put("qty", qty);
                hist.put("id", id);


                pdtlist.add(hist);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        ListAdapter adapter = new SimpleAdapter(PaymentoffActivity.this, pdtlist, R.layout.offl, new String[]{"pname","qty", "price"}, new int[]{R.id.tpitem,R.id.tqty, R.id.tpprice});


        listb.setAdapter(adapter);
        tot.setText(""+am);

    }



    public void getbill(String uid){


        String UrlData = "?uid=" + uid ;

        Log.d("url",""+UrlData);


        class BillDetails extends AsyncTask<String, Void, String> {


            ProgressDialog progressDialog;


            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog = ProgressDialog.show(PaymentoffActivity.this, "Please wait", null, true, true);


            }

            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                progressDialog.dismiss();
                 Toast.makeText(PaymentoffActivity.this, s, Toast.LENGTH_LONG).show();
                if(s!=null && s.equalsIgnoreCase("failed")){
                    Toast.makeText(PaymentoffActivity.this,"No product In cart", Toast.LENGTH_LONG).show();
                }
                else {
                    showlist(s);
                    Log.d(TAG, "onPostExecute: test  :"+s);
                }

            }

            @Override
            protected String doInBackground(String... params) {

                String s = params[0];
                Log.d("result",params[0]);
                BufferedReader bf = null;

                try {
                    URL url = new URL("http://"+ip+"/Qfree_2017/billoff.php" + s);

                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    bf = new BufferedReader(new InputStreamReader(connection.getInputStream()));


                    String result = bf.readLine();
                    return result;



                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }



            }

        }


        BillDetails cd = new BillDetails();
        cd.execute(UrlData);

    }
    public void getbillid(String uid){


        String UrlData = "?uid=" + uid+"&am="+am;

        Log.d("url",""+UrlData);


        class CartDetails extends AsyncTask<String, Void, String> {


            ProgressDialog progressDialog;


            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog = ProgressDialog.show(PaymentoffActivity.this, "Please wait", null, true, true);


            }

            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                progressDialog.dismiss();
                String b;
                Toast.makeText(PaymentoffActivity.this, s, Toast.LENGTH_LONG).show();
                showbill(s);
                // bill.setText(s);

            }

            @Override
            protected String doInBackground(String... params) {

                String s = params[0];
                Log.d("result",params[0]);
                BufferedReader bf = null;

                try {
                    URL url = new URL("http://"+ip+"/Qfree_2017/billnooff.php" + s);

                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    bf = new BufferedReader(new InputStreamReader(connection.getInputStream()));


                    String result = bf.readLine();
                    return result;



                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }



            }

        }


        CartDetails cd = new CartDetails();
        cd.execute(UrlData);

    }

    public void showbill(String res){
        Log.d("res", res);
        JSONArray jarray = null;
        try {
            jarray = new JSONArray(res);

            for (int i = 0; i < jarray.length(); i++) {
                JSONObject jobj = null;

                jobj = jarray.getJSONObject(i);


                billno= jobj.getString("bill");
                status = jobj.getString("status");

            }
            bill.setText("Bill no:     "+billno);
            sta.setText("Status:     "+status);
        } catch (JSONException e) {
            e.printStackTrace();
        }



    }


}
