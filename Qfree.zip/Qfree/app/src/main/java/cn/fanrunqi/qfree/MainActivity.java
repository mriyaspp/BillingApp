package cn.fanrunqi.qfree;

import android.app.ActivityOptions;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.transition.Explode;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnClick;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    @InjectView(R.id.et_username)
    EditText etUsername;
    @InjectView(R.id.et_password)
    EditText etPassword;
    @InjectView(R.id.bt_go)
    Button btGo;
    @InjectView(R.id.cv)
    CardView cv;
    @InjectView(R.id.fab)
    FloatingActionButton fab;
TextView tf;
    String uname="",pass="",ip="";
    SharedPreferences sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.inject(this);

        sp=getSharedPreferences("qfree", Context.MODE_PRIVATE);
        if (sp.contains("ip"))
        {
            ip=sp.getString("ip", "");
        }

        etUsername=(EditText)findViewById(R.id.et_username);
        etPassword=(EditText)findViewById(R.id.et_password);
        btGo=(Button) findViewById(R.id.bt_go);

        tf=(TextView)findViewById(R.id.txtf);

        fab=(FloatingActionButton) findViewById(R.id.fab);
        btGo.setOnClickListener(this);
        fab.setOnClickListener(this);

        tf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(MainActivity.this,ForgotPwdActivity.class);
                startActivity(i);
            }
        });
    }

    @OnClick({R.id.bt_go, R.id.fab})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.fab:
                getWindow().setExitTransition(null);
                getWindow().setEnterTransition(null);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    ActivityOptions options =
                            ActivityOptions.makeSceneTransitionAnimation(this, fab, fab.getTransitionName());
                    startActivity(new Intent(this, RegisterActivity.class), options.toBundle());
                } else {
                    startActivity(new Intent(this, RegisterActivity.class));
                }
                break;
            case R.id.bt_go:
                Explode explode = new Explode();
                explode.setDuration(500);

                getWindow().setExitTransition(explode);
                getWindow().setEnterTransition(explode);
                ActivityOptionsCompat oc2 = ActivityOptionsCompat.makeSceneTransitionAnimation(this);
                /*Intent i2 = new Intent(this,LoginSuccessActivity.class);
                startActivity(i2, oc2.toBundle());*/
                uname=etUsername.getText().toString();
                pass=etPassword.getText().toString();
                if (!validatepwd(pass)) {
                    etPassword.setError("invalid password");
                    etPassword.requestFocus();
                }else {

                    login(uname,pass);
                }
                break;
        }
    }
    public boolean validatepwd(String pwd) {
        // TODO Auto-generated method stub
        if (pwd != null && pwd.length() > 6) {

            return true;

        } else {
            return false;
        }
    }
    //////////////////////////////////////////////login/////////////////////////////////////////////////////
    public void login(String user,String pwd) {
        String UrlData = "?user=" + user +"&pwd="+pwd;



        class userlogin extends AsyncTask<String, Void, String> {


            ProgressDialog progressDialog;


            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog = ProgressDialog.show(MainActivity.this, "Please wait", null, true, true);


            }

            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                progressDialog.dismiss();
                //Toast.makeText(getApplicationContext(), "result"+s, Toast.LENGTH_LONG).show();
                if (s != null&& s.equalsIgnoreCase("failed")) {
                    Toast.makeText(getApplicationContext(), "Invalid User", Toast.LENGTH_LONG).show();

                }
               else  {
                    Toast.makeText(getApplicationContext(), "Successfully login", Toast.LENGTH_LONG).show();

                    Intent i = new Intent(MainActivity.this, HomeActivity.class);
                    i.putExtra("result",s);
                    startActivity(i);

                }


            }

            @Override
            protected String doInBackground(String... params) {

                String s = params[0];
                Log.d("result", params[0]);
                BufferedReader bf = null;

                try {
                    URL url = new URL("http://"+ip+"/Qfree_2017/user_login.php" + s);
Log.d("urll::",""+url);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    bf = new BufferedReader(new InputStreamReader(connection.getInputStream()));


                    String result = bf.readLine();
                    return result;


                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }


            }

        }


        userlogin registerUser = new userlogin();
        registerUser.execute(UrlData);


    }

}
