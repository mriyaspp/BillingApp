package cn.fanrunqi.qfree;




public class MyList {
    private String head;
    private String desc;
    private String uid,ip,offerp,pid;
    //constructor initializing values
    public MyList(String head, String desc,String ip,String offerp,String pid,String uid) {
        this.head = head;
        this.desc = desc;
        this.pid = pid;
        this.uid = uid;
        this.ip = ip;
        this.offerp =offerp;

    }

    //getters

    public String getHead() {
        return head;
    }
    public String getPid() {
        return pid;
    }
    public String getUid() {
        return uid;
    }
    public String getOfferp() {
        return offerp;
    }
    public String getDesc() {
        return desc;
    }
  /*  public String getStatus() {
        return status;
    }*/
    public String getIP() {
        return ip;
    }

}