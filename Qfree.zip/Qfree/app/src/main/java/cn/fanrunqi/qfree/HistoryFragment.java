package cn.fanrunqi.qfree;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link HistoryFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link HistoryFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class HistoryFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    String uid="",ip="",pname="",price="",date="",id="";
    ListView listb;
    ArrayList<HashMap<String, String>> pdtlist;
    SharedPreferences sp;

    private OnFragmentInteractionListener mListener;

    public HistoryFragment() {
        // Required empty public constructor
    }


    // TODO: Rename and change types and number of parameters
    public static HistoryFragment newInstance(String param1, String param2) {
        HistoryFragment fragment = new HistoryFragment();

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sp = getActivity().getSharedPreferences("qfree", Context.MODE_PRIVATE);
        if (sp.contains("ip"))
        {
            ip=sp.getString("ip", "");


        }
        if (sp.contains("uid"))
        {
            uid=sp.getString("uid", "");


        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View root_view= inflater.inflate(R.layout.fragment_history, container, false);


        listb=(ListView)root_view.findViewById(R.id.listhistory);
        pdtlist=new ArrayList<HashMap<String,String>>();

         getHistroy(uid);
        FloatingActionButton fab = (FloatingActionButton)root_view.findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                deleteAll(uid);
            }
        });
       /* bdelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            deleteAll(uid);

            }
        });*/
        return root_view;
    }
    public void showlist(String res) {
        Log.d("res", res);
        JSONArray jarray = null;
        try {
            jarray = new JSONArray(res);

            for (int i = 0; i < jarray.length(); i++) {
                JSONObject jobj = null;

                jobj = jarray.getJSONObject(i);


                pname = jobj.getString("pname");
                price = jobj.getString("price");
                date = jobj.getString("date");
                id = jobj.getString("id");


                HashMap<String, String> hist= new HashMap<String, String>();

                hist.put("pname", pname);
                hist.put("price", price);
                hist.put("date", date);
                hist.put("id", id);


                pdtlist.add(hist);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        ListAdapter adapter = new SimpleAdapter(getActivity(), pdtlist, R.layout.listhistory, new String[]{"pname", "price","date"}, new int[]{R.id.tpname, R.id.tprice,R.id.tpdate});


        listb.setAdapter(adapter);
        listb.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //final TextView tplace=(TextView)view.findViewById(R.id.txtbookplace);

                id=pdtlist.get(i).get("id");


                LayoutInflater li = LayoutInflater.from(getActivity());
                View promptsView1 = li.inflate(R.layout.prompt_history_delete, null);

                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getActivity());

                // set prompts.xml to alertdialog builder
                alertDialogBuilder.setView(promptsView1);

                final Button bdelete = (Button) promptsView1.findViewById(R.id.bdel);


                final AlertDialog alertDialog = alertDialogBuilder.create();
                bdelete.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View arg0) {
                        // TODO Auto-generated method stub
                     deleteItem(id);
                        pdtlist.remove(id);
                        //notifydatasetchanged(id);
                        alertDialog.cancel();



                    }
                });


                alertDialog.show();

            }
        });

    }
    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }

    ////////////////gethistory///////////////////////////////////////////////////////
    public void getHistroy( String uid) {

        String UrlData = "?uid=" + uid ;

        Log.d("url",""+UrlData);


        class HistoryDetails extends AsyncTask<String, Void, String> {


            ProgressDialog progressDialog;


            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog = ProgressDialog.show(getActivity(), "Please wait", null, true, true);


            }

            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                progressDialog.dismiss();
                //  Toast.makeText(getActivity(), s, Toast.LENGTH_LONG).show();
                if(s!=null && s.equalsIgnoreCase("failed")){
                    Toast.makeText(getActivity(),"History Not Available", Toast.LENGTH_LONG).show();
                }
                else if(s!=null) {

                    showlist(s);
//
                }

            }

            @Override
            protected String doInBackground(String... params) {

                String s = params[0];
                Log.d("result",params[0]);
                BufferedReader bf = null;

                try {
                    URL url = new URL("http://"+ip+"/Qfree_2017/get_history.php" + s);

                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    bf = new BufferedReader(new InputStreamReader(connection.getInputStream()));


                    String result = bf.readLine();
                    return result;



                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }



            }

        }


        HistoryDetails hi = new HistoryDetails();
        hi.execute(UrlData);


    }
    //////////////////////////////////////////////delete one item/////////////////////////////////////////////////////
    public void deleteItem(String pid) {
        String UrlData = "?pid=" + pid;




        class DeleteItem extends AsyncTask<String, Void, String> {


            ProgressDialog progressDialog;


            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog = ProgressDialog.show(getActivity(), "Please wait", null, true, true);


            }

            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                progressDialog.dismiss();
                Log.d("result",s);

                if (s != null&& s.equalsIgnoreCase("failed")) {
                    Toast.makeText(getActivity(), "failed to delete Product", Toast.LENGTH_LONG).show();

                }
                else  if (s != null&& s.equalsIgnoreCase("success")) {
                    Toast.makeText(getActivity(), "Item Deleted", Toast.LENGTH_LONG).show();

                }
                else{
                    Toast.makeText(getActivity(), "Connection Error", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            protected String doInBackground(String... params) {

                String s = params[0];
                Log.d("result", params[0]);
                BufferedReader bf = null;

                try {
                    URL url = new URL("http://"+ip+"/Qfree_2017/delete_history_item.php" + s);

                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    bf = new BufferedReader(new InputStreamReader(connection.getInputStream()));


                    String result = bf.readLine();
                    return result;


                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }


            }

        }


        DeleteItem dele = new DeleteItem();
        dele.execute(UrlData);


    }
    //////////////////////////////////////////////delete All/////////////////////////////////////////////////////
    public void deleteAll(String uid) {
        String UrlData = "?uid=" + uid;




        class DeleteAll extends AsyncTask<String, Void, String> {


            ProgressDialog progressDialog;


            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog = ProgressDialog.show(getActivity(), "Please wait", null, true, true);


            }

            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                progressDialog.dismiss();
                Log.d("result",s);

                if (s != null&& s.equalsIgnoreCase("failed")) {
                    Toast.makeText(getActivity(), "failed to Clear history", Toast.LENGTH_LONG).show();

                }
                else  if (s != null&& s.equalsIgnoreCase("success")) {
                    Toast.makeText(getActivity(), "Clear History", Toast.LENGTH_LONG).show();

                }
                else{
                    Toast.makeText(getActivity(), "Connection Error", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            protected String doInBackground(String... params) {

                String s = params[0];
                Log.d("result", params[0]);
                BufferedReader bf = null;

                try {
                    URL url = new URL("http://"+ip+"/Qfree_2017/delete_history_all.php" + s);

                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    bf = new BufferedReader(new InputStreamReader(connection.getInputStream()));


                    String result = bf.readLine();
                    return result;


                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }


            }

        }


        DeleteAll deleAll = new DeleteAll();
        deleAll.execute(UrlData);


    }

}
