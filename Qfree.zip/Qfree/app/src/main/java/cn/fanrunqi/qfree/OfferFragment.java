package cn.fanrunqi.qfree;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


public class OfferFragment extends Fragment {
    SharedPreferences sp;
    String ip = "", dest = "";
    int c;
    Fragment fg = null;
    String details = "", pname = "", price = "", offerp = "", uid = "", pid = "";
    //recyclerview objects
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    private RecyclerView.Adapter adapter;

    //model object for our list data
    private List<MyList> list;
    private OnFragmentInteractionListener mListener;

    public OfferFragment() {
        // Required empty public constructor
    }

    // TODO: Rename and change types and number of parameters
    public static OfferFragment newInstance(String param1, String param2) {
        OfferFragment fragment = new OfferFragment();

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        sp=getActivity().getSharedPreferences("qfree", Context.MODE_PRIVATE);
        if (sp.contains("ip"))
        {
            ip=sp.getString("ip", "");
        }
        if (sp.contains("uid"))
        {
            uid=sp.getString("uid", "");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root_view = inflater.inflate(R.layout.fragment_offer, container, false);

        recyclerView = (RecyclerView) root_view.findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        list = new ArrayList<>();
        details = getArguments().getString("details");
      //  Toast.makeText(getActivity(), details, Toast.LENGTH_LONG).show();
        try {
            JSONArray jarray = new JSONArray(details);
            for (int i = 0; i < jarray.length(); i++) {
                JSONObject json_data = jarray.getJSONObject(i);

                pname = json_data.getString("pname");
                price = json_data.getString("price");
                //  status= json_data.getString("status");
                offerp = json_data.getString("offerprice");
                pid = json_data.getString("pid");
                loadRecyclerViewItem();

            }
        } catch (Exception e) {        // TODO Auto-generated catch block
            e.printStackTrace();
        }
return  root_view;
    }

    private void loadRecyclerViewItem() {
        //you can fetch the data from server or some apis
        //for this tutorial I am adding some dummy data directly
     //  for (int i = 1; i <= 5; i++) {
        MyList myList = new MyList(pname ,price,ip,offerp,pid,uid);
        list.add(myList);
       //  }

        adapter = new CustomAdapter(list, getActivity());
        recyclerView.setAdapter(adapter);
    }
    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
