package cn.fanrunqi.qfree;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class IPActivity extends AppCompatActivity {
    EditText edip;
    Button bok;
    SharedPreferences sp;
    String ip = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ip);

       /* edip = (EditText) findViewById(R.id.edip);
        bok = (Button) findViewById(R.id.bok);*/
        sp = getSharedPreferences("qfree", Context.MODE_PRIVATE);
        if (sp.contains("ip")) {
            ip = sp.getString("ip", "");
        }
//edip.setText(ip);
       /* Toast.makeText(getApplicationContext(),""+ip, Toast.LENGTH_LONG).show();
        bok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ip=edip.getText().toString();
                SharedPreferences.Editor editor = sp.edit();
                editor.putString("ip", ip);
                editor.commit();
                Intent i=new Intent(IPActivity.this,SplashActivity.class);

                startActivity(i);
            }
        });*/
        LayoutInflater li = LayoutInflater.from(IPActivity.this);
        View promptsView = li.inflate(R.layout.prompts, null);

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(IPActivity.this);

        // set prompts.xml to alertdialog builder
        alertDialogBuilder.setView(promptsView);

        final EditText userInput = (EditText) promptsView
                .findViewById(R.id.editTextDialogUserInput);
        userInput.setText(ip);
        // set dialog message
        alertDialogBuilder.setTitle("Enter Server Address")
                .setCancelable(false)
                .setPositiveButton("OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // get user input and set it to result
                                // edit text
                                ip = userInput.getText().toString();
                                SharedPreferences.Editor editor = sp.edit();
                                editor.putString("ip", ip);
                                editor.commit();
                                Intent i = new Intent(IPActivity.this, SplashActivity.class);

                                startActivity(i);

                            }
                        })
                .setNegativeButton("Cancel",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                                IPActivity.this.finish();
                            }
                        });

        // create alert dialog
        AlertDialog alertDialog = alertDialogBuilder.create();

        // show it
        alertDialog.show();


    }

}
