package cn.fanrunqi.qfree;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class ForgotPwdActivity extends AppCompatActivity {
Button b;
    EditText ed;
    SharedPreferences sp;
    String ip="",adno="",em="",pass="",type="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_pwd);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        sp= getSharedPreferences("qfree", Context.MODE_PRIVATE);
        if (sp.contains("ip"))
        {
            ip=sp.getString("ip", "");


        }
        if (sp.contains("uid"))
        {
            adno=sp.getString("uid", "");


        }  if (sp.contains("type"))
        {
            type=sp.getString("type", "");


        }

        b=(Button)findViewById(R.id.bs);
        ed=(EditText)findViewById(R.id.edfem);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String em=ed.getText().toString();
                CheckEmail(em,adno);
                Intent i=new Intent(ForgotPwdActivity.this,MainActivity.class);
                startActivity(i);
            }
        });
    }

    public void CheckEmail(final String email, String admno) {
        String UrlData = "?adno=" + admno + "&email=" + email ;
     //   Toast.makeText(getApplicationContext(), UrlData, Toast.LENGTH_LONG).show();


        class EmailUser extends AsyncTask<String, Void, String> {


            ProgressDialog progressDialog;


            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog = ProgressDialog.show(ForgotPwdActivity.this, "Please wait", null, true, true);


            }

            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                progressDialog.dismiss();
                // Toast.makeText(getApplicationContext(), s, Toast.LENGTH_LONG).show();
                if(s!=null && s.equalsIgnoreCase("failed")){

                    ed.setError("Incorrect Email ID");

                }
                else {
                    try {
                        JSONArray jarray=new JSONArray(s);
                        for(int i=0;i<jarray.length();i++){
                            JSONObject json_data=jarray.getJSONObject(i);

                            pass=json_data.getString("password");
                            em= json_data.getString("email");
                          //  image= json_data.getString("photo");

                        }
                    } catch (Exception e) {        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                SendEmail(em,pass);
                }



            }

            @Override
            protected String doInBackground(String... params) {

                String s = params[0];
                Log.d("result",params[0]);
                BufferedReader bf = null;

                try {
                    URL url = new URL("http://"+ip+"/Qfree_2017/check_email.php" + s);

                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    bf = new BufferedReader(new InputStreamReader(connection.getInputStream()));


                    String result = bf.readLine();
                    return result;



                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }



            }

        }


        EmailUser em = new EmailUser();
        em.execute(UrlData);


    }


    public void SendEmail(final String email, String pwd) {
        String UrlData = "?email="+email+"&msg="+pwd;
        //   Toast.makeText(getApplicationContext(), UrlData, Toast.LENGTH_LONG).show();


        class EmailUser1 extends AsyncTask<String, Void, String> {


            ProgressDialog progressDialog;


            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog = ProgressDialog.show(ForgotPwdActivity.this, "Please wait", null, true, true);


            }

            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                progressDialog.dismiss();
                // Toast.makeText(getApplicationContext(), s, Toast.LENGTH_LONG).show();
            }

            @Override
            protected String doInBackground(String... params) {

                String s = params[0];
                Log.d("result",params[0]);
                BufferedReader bf = null;

                try {
                    URL url = new URL("http://cloudviews.in/SMS/gateway.php" + s);

                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    bf = new BufferedReader(new InputStreamReader(connection.getInputStream()));


                    String result = bf.readLine();
                    return result;



                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }



            }

        }


        EmailUser1 em1 = new EmailUser1();
        em1.execute(UrlData);


    }


}
