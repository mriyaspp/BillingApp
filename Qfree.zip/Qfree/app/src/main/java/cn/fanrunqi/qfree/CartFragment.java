package cn.fanrunqi.qfree;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;


public class CartFragment extends Fragment  {
    // TODO: Rename parameter arguments, choose names that match
    String uid="",ip="",pname="",price="",id="";
    int total;
    ListView listb;
    ArrayList<HashMap<String, String>> pdtlist;
    SharedPreferences sp;
    TextView tot;
    //private SwipeRefreshLayout swipeRefreshLayout;

    private OnFragmentInteractionListener mListener;

    public CartFragment() {
        // Required empty public constructor
    }


    // TODO: Rename and change types and number of parameters
    public static CartFragment newInstance(String param1, String param2) {
        CartFragment fragment = new CartFragment();

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sp = getActivity().getSharedPreferences("qfree", Context.MODE_PRIVATE);
        if (sp.contains("ip"))
        {
            ip=sp.getString("ip", "");


        }
        if (sp.contains("uid"))
        {
            uid=sp.getString("uid", "");


        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View root_view= inflater.inflate(R.layout.fragment_cart, container, false);


        listb=(ListView)root_view.findViewById(R.id.listcart);
        tot=(TextView)root_view.findViewById(R.id.tot);

        pdtlist=new ArrayList<HashMap<String,String>>();
        //swipeRefreshLayout = (SwipeRefreshLayout)root_view.findViewById(R.id.swipe_refresh_layout);

        getCart(uid);
        FloatingActionButton fabc = (FloatingActionButton)root_view.findViewById(R.id.fabcart);
        fabc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // deleteAll(uid);
                Fragment fragment = null;
                fragment = new PurchaseFragment();
                if (fragment != null) {
                    FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
                    ft.replace(R.id.content_frame, fragment);
                    ft.commit();
                }
            }
        });
       // swipeRefreshLayout.setOnRefreshListener();

//        swipeRefreshLayout.post(new Runnable() {
//            @Override
//            public void run() {
//                swipeRefreshLayout.setRefreshing(true);
//
//               // getCart(uid);
//            }
//        });

        return root_view;
    }
    public void showlist(String res) {
        Log.d("res", res);
        JSONArray jarray = null;
        try {
            jarray = new JSONArray(res);

            for (int i = 0; i < jarray.length(); i++) {
                JSONObject jobj = null;

                jobj = jarray.getJSONObject(i);


                pname = jobj.getString("pname");
                price = jobj.getString("price");

                id = jobj.getString("id");
                total+=Integer.parseInt(price);


                HashMap<String, String> hist= new HashMap<String, String>();

                hist.put("pname", pname);
                hist.put("price", price);

                hist.put("id", id);


                pdtlist.add(hist);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        final  ListAdapter adapter = new SimpleAdapter(getActivity(), pdtlist, R.layout.listcart, new String[]{"pname", "price"}, new int[]{R.id.titem, R.id.tiprice});


        listb.setAdapter(adapter);
        tot.setText("Total price         " +total);
        listb.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //final TextView tplace=(TextView)view.findViewById(R.id.txtbookplace);

                id=pdtlist.get(i).get("id");


                LayoutInflater li = LayoutInflater.from(getActivity());
                View promptsView1 = li.inflate(R.layout.prompt_history_delete, null);

                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getActivity());

                // set prompts.xml to alertdialog builder
                alertDialogBuilder.setView(promptsView1);

                final Button bdelete = (Button) promptsView1.findViewById(R.id.bdel);


                final AlertDialog alertDialog = alertDialogBuilder.create();
                bdelete.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View arg0) {
                        // TODO Auto-generated method stub

                        pdtlist.remove(id);

                        deleteCartItem(id);
                        alertDialog.cancel();


                    }
                });


                alertDialog.show();

            }
        });

    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
    ////////////////getCart///////////////////////////////////////////////////////
    public void getCart( String uid) {

        String UrlData = "?uid=" + uid ;

        Log.d("url",""+UrlData);


        class CartDetails extends AsyncTask<String, Void, String> {


            ProgressDialog progressDialog;


            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog = ProgressDialog.show(getActivity(), "Please wait", null, true, true);


            }

            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                progressDialog.dismiss();
               //  Toast.makeText(getActivity(), s, Toast.LENGTH_LONG).show();
                if(s!=null && s.equalsIgnoreCase("failed")){
                    Toast.makeText(getActivity(),"No product In cart", Toast.LENGTH_LONG).show();
                }
                else {
                    showlist(s);
//
                }

            }

            @Override
            protected String doInBackground(String... params) {

                String s = params[0];
                Log.d("result",params[0]);
                BufferedReader bf = null;

                try {
                    URL url = new URL("http://"+ip+"/Qfree_2017/get_cart.php" + s);

                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    bf = new BufferedReader(new InputStreamReader(connection.getInputStream()));


                    String result = bf.readLine();
                    return result;



                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }



            }

        }


        CartDetails cd = new CartDetails();
        cd.execute(UrlData);


    }
    //////////////////////////////////////////////delete one item/////////////////////////////////////////////////////
    public void deleteCartItem(String pid) {
        String UrlData = "?pid=" + pid;




        class DeleteItem extends AsyncTask<String, Void, String> {


            ProgressDialog progressDialog;


            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog = ProgressDialog.show(getActivity(), "Please wait", null, true, true);


            }

            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                progressDialog.dismiss();
                Log.d("result",s);

                if (s != null&& s.equalsIgnoreCase("failed")) {
                    Toast.makeText(getActivity(), "failed to delete Product", Toast.LENGTH_LONG).show();

                }
                else  if (s != null&& s.equalsIgnoreCase("success")) {
                    Toast.makeText(getActivity(), "Item Deleted", Toast.LENGTH_LONG).show();
                   // ((BaseAdapter)adapter).notifyDataSetChanged();
                }
                else{
                    Toast.makeText(getActivity(), "Connection Error", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            protected String doInBackground(String... params) {

                String s = params[0];
                Log.d("result", params[0]);
                BufferedReader bf = null;

                try {
                    URL url = new URL("http://"+ip+"/Qfree_2017/delete_cart_item.php" + s);

                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    bf = new BufferedReader(new InputStreamReader(connection.getInputStream()));


                    String result = bf.readLine();
                    return result;


                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }


            }

        }


        DeleteItem dele = new DeleteItem();
        dele.execute(UrlData);


    }
}
