package cn.fanrunqi.qfree;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.transition.Transition;
import android.transition.TransitionInflater;
import android.util.Log;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.view.animation.AccelerateInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import butterknife.ButterKnife;
import butterknife.InjectView;

public class RegisterActivity extends AppCompatActivity {

    @InjectView(R.id.fab)
    FloatingActionButton fab;
    @InjectView(R.id.cv_add)
    CardView cvAdd;
    EditText euser,eemail,eph,epwd,erpwd,ename,eacc,eaddr;
    Button breg;
    String user="",email="",ph="",pwd="",rpwd="",emailpattern="",ip="",name="",acc="",addr="",namepattern="";
    SharedPreferences sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        ButterKnife.inject(this);

        euser=(EditText)findViewById(R.id.et_username);
        eemail=(EditText)findViewById(R.id.et_email);
        eph=(EditText)findViewById(R.id.et_ph);
        epwd=(EditText)findViewById(R.id.et_password);
        ename=(EditText)findViewById(R.id.et_name);
        eacc=(EditText)findViewById(R.id.et_acc);
        eaddr=(EditText)findViewById(R.id.et_addr);
        erpwd=(EditText)findViewById(R.id.et_repeatpassword);

        breg=(Button) findViewById(R.id.bt_go);
        sp=getSharedPreferences("qfree", Context.MODE_PRIVATE);
        if (sp.contains("ip"))
        {
            ip=sp.getString("ip", "");
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            ShowEnterAnimation();
        }
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                animateRevealClose();
            }
        });
        breg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                email=eemail.getText().toString();
                ph=eph.getText().toString();
                user=euser.getText().toString();
                name=ename.getText().toString();
                acc=eacc.getText().toString();
                addr=eaddr.getText().toString();
                pwd=epwd.getText().toString();
                rpwd=erpwd.getText().toString();
                if (!validatename(name)) {
                    ename.setError("invalid Name");
                    ename.requestFocus();
                }
                else if (!validateemail(email)) {
                    eemail.setError("invalid email id");
                    eemail.requestFocus();
                } else if (!validatephone(ph)) {
                    eph.setError("invalid phone number");
                    eph.requestFocus();
                }
                else if (!validatepwd(pwd)) {
                    epwd.setError("invalid password");
                    epwd.requestFocus();
                }
                else if (!validatecpwd(rpwd)) {
                    erpwd.setError("invalid password");
                    erpwd.requestFocus();
                }else {

                  register(user,email,ph,pwd,name,acc,addr);
                }
                //Toast.makeText(RegisterActivity.this,""+email+user+ph+pwd,Toast.LENGTH_LONG).show();
            }
        });
    }

    public boolean validateemail(String email) {
        // TODO Auto-generated method stub
        emailpattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
        Pattern pat = Pattern.compile(emailpattern);
        Matcher match = pat.matcher(email);
        return match.matches();
        //	return false;
    }
    public boolean validatename(String name) {
        // TODO Auto-generated method stub
       /* namepattern = "[A-Z][a-zA-Z]*";
        Pattern pat = Pattern.compile(namepattern);
        Matcher match = pat.matcher(name);*/
        return name.matches("[A-Z][a-zA-Z]*");
        //	return false;
    }
    public boolean validatephone(String ph) {
        // TODO Auto-generated method stub
        if (ph.length()>=10 ) {

            return true;

        } else {
            return false;
        }
    }

    public boolean validatepwd(String pwd) {
        // TODO Auto-generated method stub
        if (pwd != null && pwd.length() > 6) {

            return true;

        } else {
            return false;
        }
    }
    public boolean validatecpwd(String cpwd) {
        // TODO Auto-generated method stub
        if (cpwd != null && cpwd.length() > 6) {
            if (cpwd.equals(pwd))
                return true;
            return true;
        } else {
            return false;
        }
    }

    private void ShowEnterAnimation() {
        Transition transition = TransitionInflater.from(this).inflateTransition(R.transition.fabtransition);
        getWindow().setSharedElementEnterTransition(transition);

        transition.addListener(new Transition.TransitionListener() {
            @Override
            public void onTransitionStart(Transition transition) {
                cvAdd.setVisibility(View.GONE);
            }

            @Override
            public void onTransitionEnd(Transition transition) {
                transition.removeListener(this);
                animateRevealShow();
            }

            @Override
            public void onTransitionCancel(Transition transition) {

            }

            @Override
            public void onTransitionPause(Transition transition) {

            }

            @Override
            public void onTransitionResume(Transition transition) {

            }


        });
    }

    public void animateRevealShow() {
        Animator mAnimator = ViewAnimationUtils.createCircularReveal(cvAdd, cvAdd.getWidth()/2,0, fab.getWidth() / 2, cvAdd.getHeight());
        mAnimator.setDuration(500);
        mAnimator.setInterpolator(new AccelerateInterpolator());
        mAnimator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
            }

            @Override
            public void onAnimationStart(Animator animation) {
                cvAdd.setVisibility(View.VISIBLE);
                super.onAnimationStart(animation);
            }
        });
        mAnimator.start();
    }

    public void animateRevealClose() {
        Animator mAnimator = ViewAnimationUtils.createCircularReveal(cvAdd,cvAdd.getWidth()/2,0, cvAdd.getHeight(), fab.getWidth() / 2);
        mAnimator.setDuration(500);
        mAnimator.setInterpolator(new AccelerateInterpolator());
        mAnimator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                cvAdd.setVisibility(View.INVISIBLE);
                super.onAnimationEnd(animation);
                fab.setImageResource(R.drawable.plus);
                RegisterActivity.super.onBackPressed();
            }

            @Override
            public void onAnimationStart(Animator animation) {
                super.onAnimationStart(animation);
            }
        });
        mAnimator.start();
    }
    @Override
    public void onBackPressed() {
        animateRevealClose();
    }

    //////////////////////////////////////////////register/////////////////////////////////////////////////////
    public void register(String user,String email,String ph,String pwd,String name,String acc,String addr) {
        String UrlData = "?user=" + user + "&email="+email+"&ph="+ph+"&pwd="+pwd+"&name="+name+"&acc="+acc+"&addr="+addr;
        // Toast.makeText(getApplicationContext(), UrlData+""+ip, Toast.LENGTH_LONG).show();


        class RegisterUser extends AsyncTask<String, Void, String> {


            ProgressDialog progressDialog;


            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog = ProgressDialog.show(RegisterActivity.this, "Please wait", null, true, true);


            }

            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                progressDialog.dismiss();
            //    Toast.makeText(getApplicationContext(), "sdsassssssss"+s, Toast.LENGTH_LONG).show();
                if (s != null&& s.equalsIgnoreCase("failed")) {
                    Toast.makeText(getApplicationContext(), "Registration Failed", Toast.LENGTH_LONG).show();

                }
                else if (s != null && s.equalsIgnoreCase("exist")) {
                    Toast.makeText(getApplicationContext(), "Already Registered", Toast.LENGTH_LONG).show();

                }else if (s != null && s.equalsIgnoreCase("success")) {
                    euser.setText("");
                    eemail.setText("");
                    eph.setText("");
                    epwd.setText("");

                    Intent i = new Intent(RegisterActivity.this, MainActivity.class);

                    startActivity(i);

                }
                else{
                    Toast.makeText(getApplicationContext(), "Problem loading", Toast.LENGTH_LONG).show();
                }


            }

            @Override
            protected String doInBackground(String... params) {

                String s = params[0];
                Log.d("result", params[0]);
                BufferedReader bf = null;

                try {
                    URL url = new URL("http://"+ip+"/Qfree_2017/user_register.php" + s);

                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    bf = new BufferedReader(new InputStreamReader(connection.getInputStream()));


                    String result = bf.readLine();
                    return result;


                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }


            }

        }


        RegisterUser registerUser = new RegisterUser();
        registerUser.execute(UrlData);


    }


}
