package cn.fanrunqi.qfree;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EditProfileActivity extends AppCompatActivity {
    EditText eemail,eph,ename,eacc,eaddr,euser,epwd;
    Button breg;
    String uid="",email="",ph="",emailpattern="",ip="",name="",acc="",addr="",details="",user="",pwd="";
    SharedPreferences sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);


        eemail=(EditText)findViewById(R.id.et_email);
        eph=(EditText)findViewById(R.id.et_ph);
         ename=(EditText)findViewById(R.id.et_name);
        eacc=(EditText)findViewById(R.id.et_acc);
        eaddr=(EditText)findViewById(R.id.et_addr);
        euser=(EditText)findViewById(R.id.et_uid);
        epwd=(EditText)findViewById(R.id.et_pwd);




        breg=(Button) findViewById(R.id.bt_go);

details=getIntent().getStringExtra("details");
        sp=getSharedPreferences("qfree", Context.MODE_PRIVATE);
        if (sp.contains("ip"))
        {
            ip=sp.getString("ip", "");
        } if (sp.contains("uid"))
        {
            uid=sp.getString("uid", "");
        }

        try {
            JSONArray jarray=new JSONArray(details);
            for(int i=0;i<jarray.length();i++){
                JSONObject json_data=jarray.getJSONObject(i);

                eacc.setText(json_data.getString("account"));
                eaddr.setText(json_data.getString("address"));
                ename.setText(json_data.getString("name"));
                eemail.setText(json_data.getString("email"));
                eph.setText(json_data.getString("phone"));
                euser.setText(json_data.getString("username"));
                epwd.setText(json_data.getString("password"));

                //details+=json_data.getString("longitude");
                // location= json_data.getString("location");

            }
        } catch (Exception e) {        // TODO Auto-generated catch block
            e.printStackTrace();
        }

        breg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                email=eemail.getText().toString();
                ph=eph.getText().toString();

                name=ename.getText().toString();
                acc=eacc.getText().toString();
                addr=eaddr.getText().toString();
                user=euser.getText().toString();
                pwd=epwd.getText().toString();

                if (!validateemail(email)) {
                    eemail.setError("invalid email id");
                    eemail.requestFocus();
                } else if (!validatephone(ph)) {
                    eph.setError("invalid phone number");
                    eph.requestFocus();
                }
                else {

                    register(email,ph,name,acc,addr,user,pwd);
                }
                //Toast.makeText(RegisterActivity.this,""+email+user+ph+pwd,Toast.LENGTH_LONG).show();
            }
        });
    }

    public boolean validateemail(String email) {
        // TODO Auto-generated method stub
        emailpattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
        Pattern pat = Pattern.compile(emailpattern);
        Matcher match = pat.matcher(email);
        return match.matches();
        //	return false;
    }
    public boolean validatephone(String ph) {
        // TODO Auto-generated method stub
        if (ph.length()>=10 && ph.length() <=12) {

            return true;

        } else {
            return false;
        }
    }

    public boolean validatepwd(String pwd) {
        // TODO Auto-generated method stub
        if (pwd != null && pwd.length() > 6) {

            return true;

        } else {
            return false;
        }
    }


    //////////////////////////////////////////////register/////////////////////////////////////////////////////
    public void register(String email,String ph,String name,String acc,String addr,String user,String pwd) {
        String UrlData = "?email="+email+"&ph="+ph+"&name="+name+"&acc="+acc+"&addr="+addr+"&uid="+uid+"&user="+user+"&pwd="+pwd;
         //Toast.makeText(getApplicationContext(), UrlData+""+ip, Toast.LENGTH_LONG).show();


        class RegisterUser extends AsyncTask<String, Void, String> {


            ProgressDialog progressDialog;


            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog = ProgressDialog.show(EditProfileActivity.this, "Please wait", null, true, true);


            }

            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                progressDialog.dismiss();
               /* Toast.makeText(getApplicationContext(), "sdsassssssss"+s, Toast.LENGTH_LONG).show();
                if (s != null&& s.equalsIgnoreCase("failed")) {
                    Toast.makeText(getApplicationContext(), "Registration Failed", Toast.LENGTH_LONG).show();

                }
                else if (s != null && s.equalsIgnoreCase("exist")) {
                    Toast.makeText(getApplicationContext(), "Already Registered", Toast.LENGTH_LONG).show();

                }else if (s != null && s.equalsIgnoreCase("success")) {*/
                    ename.setText("");
                    eacc.setText("");
                    eaddr.setText("");
                    eph.setText("");
                    eemail.setText("");

                    Intent i = new Intent(EditProfileActivity.this, MainActivity.class);

                    startActivity(i);
/*
                }
                else{
                    Toast.makeText(getApplicationContext(), "Problem loading", Toast.LENGTH_LONG).show();
                }*/


            }

            @Override
            protected String doInBackground(String... params) {

                String s = params[0];
                Log.d("result", params[0]);
                BufferedReader bf = null;

                try {
                    URL url = new URL("http://"+ip+"/Qfree_2017/edit_profile.php" + s);
                    Log.d("key",""+url);

                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    bf = new BufferedReader(new InputStreamReader(connection.getInputStream()));


                    String result = bf.readLine();
                    return result;


                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }


            }

        }


        RegisterUser registerUser = new RegisterUser();
        registerUser.execute(UrlData);


    }

}
