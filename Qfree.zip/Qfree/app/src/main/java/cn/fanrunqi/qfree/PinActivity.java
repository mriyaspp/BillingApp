package cn.fanrunqi.qfree;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class PinActivity extends AppCompatActivity implements SensorEventListener{
WebView wv;
    SharedPreferences sp;
    String ip="",acc="",am="",pin="",uid="";
    private SensorManager mSensorManager;
    private Sensor mSensor;
    private static final int SENSOR_SENSITIVITY = 4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pin);

        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
      mSensor= mSensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);

        sp = getSharedPreferences("qfree", Context.MODE_PRIVATE);
        if (sp.contains("ip"))
        {
            ip=sp.getString("ip", "");


        }
        if (sp.contains("uid"))
        {
            uid=sp.getString("uid", "");


        }
        am=getIntent().getStringExtra("total");
        acc=getIntent().getStringExtra("acc");
        wv=new WebView(this);



        wv.getSettings().setUseWideViewPort(false);
        wv.getSettings().setLoadWithOverviewMode(true);
        wv.getSettings().setJavaScriptEnabled(true);
        wv.getSettings().setSupportZoom(false);
        wv.addJavascriptInterface(new WebAppInterface(this), "android");
        wv.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }
        });
        wv.loadUrl("http://" + ip + "/Qfree_2017/shuffle.php");
        setContentView(wv);
    }
    public  void alert(String t){

            pin=t;
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(PinActivity.this);


        alertDialogBuilder.setTitle("Confirm")
                .setCancelable(false)
                .setPositiveButton("OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,int id) {
                            CheckPin(pin,acc,am,uid);
                                dialog.cancel();
                            }
                        })
                .setNegativeButton("Cancel",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,int id) {
                                dialog.cancel();

                            }
                        });

        // create alert dialog
        AlertDialog alertDialog = alertDialogBuilder.create();

        // show it
        alertDialog.show();


    }
    public class WebAppInterface {
        Context mContext;

        /** Instantiate the interface and set the context */
        WebAppInterface(Context c) {
            mContext = c;
        }

        /** Show a toast from the web page */
        @JavascriptInterface
        public void showToast(String toast) {
         //  Toast.makeText(mContext, toast, Toast.LENGTH_SHORT).show();
alert(toast);
        }
    }
    @Override
    protected void onResume() {
        super.onResume();
        mSensorManager.registerListener(this, mSensor, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        mSensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
       // if (event.sensor.getType() == Sensor.TYPE_PROXIMITY) {
            if (event.values[0] <5) {
                Toast.makeText(PinActivity.this, "pin", Toast.LENGTH_SHORT).show();
                wv.loadUrl("http://" + ip +"/Qfree_2017/normal.php");
                // near

               // setContentView(wv);
            } else {
                // far
                Toast.makeText(PinActivity.this, "far", Toast.LENGTH_SHORT).show();
                wv.loadUrl("http://" + ip +"/Qfree_2017/shuffle.php");
               /* wv.loadUrl("http://www.google.com");normal
                setContentView(wv);*/
            }

       // }
        /*if(event.values[0] < mSensor.getMaximumRange()) {
            // Detected something nearby
            getWindow().getDecorView().setBackgroundColor(Color.RED);
        } else {
            // Nothing is nearby
            getWindow().getDecorView().setBackgroundColor(Color.GREEN);
        }*/

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }
    //////////////////////////////////////////////getdetails/////////////////////////////////////////////////////
    public void CheckPin(String pin, final String acc, final String am, String uid) {
        String UrlData = "?pin=" + pin+"&acc=" + acc+"&am=" + am+"&uid=" + uid;

        // Toast.makeText(getApplicationContext(), "details"+UrlData, Toast.LENGTH_LONG).show();

        class Details extends AsyncTask<String, Void, String> {


            ProgressDialog progressDialog;


            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog = ProgressDialog.show(PinActivity.this, "Please wait", null, true, true);


            }

            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                progressDialog.dismiss();
//                Log.d("result",s);
                Toast.makeText(PinActivity.this,""+s, Toast.LENGTH_LONG).show();
                if(s!=null && s.equalsIgnoreCase("failed")){
                    Toast.makeText(PinActivity.this,"Your Account Does not have Enough Balance", Toast.LENGTH_LONG).show();
                }
                else if(s!=null && s.equalsIgnoreCase("accerror")){
                    Toast.makeText(PinActivity.this,"Account Does exist", Toast.LENGTH_LONG).show();
                }
                else if(s!=null && s.equalsIgnoreCase("pin")){
                    Toast.makeText(PinActivity.this,"Incorrect Pin", Toast.LENGTH_LONG).show();
                }
                else if(s!=null && s.equalsIgnoreCase("success")){
                    Toast.makeText(PinActivity.this,"Payment Success", Toast.LENGTH_LONG).show();
                    Intent i=new Intent(PinActivity.this,BillActivity.class);
                    i.putExtra("total",am);
                    i.putExtra("acc",acc);
                    startActivity(i);
                }

            }

            @Override
            protected String doInBackground(String... params) {

                String s = params[0];
                Log.d("result", params[0]);
                BufferedReader bf = null;

                try {
                    URL url = new URL("http://"+ip+"/Qfree_2017/pay.php" + s);

                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    bf = new BufferedReader(new InputStreamReader(connection.getInputStream()));


                    String result = bf.readLine();
                    return result;


                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }


            }

        }


        Details detail = new Details();
        detail.execute(UrlData);


    }
}
