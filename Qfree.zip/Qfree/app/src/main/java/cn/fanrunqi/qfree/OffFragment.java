package cn.fanrunqi.qfree;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link OffFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link OffFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class OffFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER

    String uid="",ip="",pname="",price="",id="",qty="";
    int total;
    ListView listb;
    ArrayList<HashMap<String, String>> pdtlist;
    SharedPreferences sp;
    TextView tot;
   // Button bp;

    // TODO: Rename and change types of parameters
    private OnFragmentInteractionListener mListener;

    public OffFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment OffFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static OffFragment newInstance(String param1, String param2) {
        OffFragment fragment = new OffFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sp = getActivity().getSharedPreferences("qfree", Context.MODE_PRIVATE);
        if (sp.contains("ip"))
        {
            ip=sp.getString("ip", "");


        }
        if (sp.contains("uid"))
        {
            uid=sp.getString("uid", "");


        }


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root_view= inflater.inflate(R.layout.fragment_off, container, false);
        listb=(ListView)root_view.findViewById(R.id.listcartpay);
        tot=(TextView)root_view.findViewById(R.id.total);
       // bp=(Button) root_view.findViewById(R.id.bpay);
        pdtlist=new ArrayList<HashMap<String,String>>();

        getlist(uid);
        return root_view;
    }
    public void showlist(String res) {
        Log.d("res", res);
        JSONArray jarray = null;
        try {
            jarray = new JSONArray(res);

            for (int i = 0; i < jarray.length(); i++) {
                JSONObject jobj = null;

                jobj = jarray.getJSONObject(i);


                pname = jobj.getString("pname");
                price = jobj.getString("price");
                qty = jobj.getString("qty");
                id = jobj.getString("pid");
                total+=Integer.parseInt(price);


                HashMap<String, String> hist= new HashMap<String, String>();

                hist.put("pname", pname);
                hist.put("price", price);
                hist.put("qty", qty);
                hist.put("id", id);


                pdtlist.add(hist);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        ListAdapter adapter = new SimpleAdapter(getActivity(), pdtlist, R.layout.list_bill, new String[]{"pname","qty", "price"}, new int[]{R.id.tpitem,R.id.tqty, R.id.tpprice});


        listb.setAdapter(adapter);
        tot.setText(""+total);

    }
    public void getlist( String uid) {

        String UrlData = "?uid=" + uid ;

        Log.d("url",""+UrlData);


        class GetDetails extends AsyncTask<String, Void, String> {


            ProgressDialog progressDialog;


            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog = ProgressDialog.show(getActivity(), "Please wait", null, true, true);


            }

            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                progressDialog.dismiss();
                //  Toast.makeText(getActivity(), s, Toast.LENGTH_LONG).show();
                if(s!=null && s.equalsIgnoreCase("failed")){
                    Toast.makeText(getActivity(),"No product In cart", Toast.LENGTH_LONG).show();
                }
                else {
                    showlist(s);
//
                }

            }

            @Override
            protected String doInBackground(String... params) {

                String s = params[0];
                Log.d("result",params[0]);
                BufferedReader bf = null;

                try {
                    URL url = new URL("http://"+ip+"/Qfree_2017/payment.php" + s);

                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    bf = new BufferedReader(new InputStreamReader(connection.getInputStream()));


                    String result = bf.readLine();
                    return result;



                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }



            }

        }


        GetDetails cd = new GetDetails();
        cd.execute(UrlData);

    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
