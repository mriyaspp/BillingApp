package cn.fanrunqi.qfree;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Paint;
import android.os.AsyncTask;
import android.support.v7.widget.CardView;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

/**
 * Created by Belal on 29/09/16.
 */

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.ViewHolder> {

    private List<MyList> list;
    private Context mCtx;
    int p;
String st="",ip="",offerp="",pname="",uid="",price="",pid="";
    public CustomAdapter(List<MyList> list, Context mCtx) {
        this.list = list;
        this.mCtx = mCtx;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_offer, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        final MyList myList = list.get(position);
        holder.textViewHead.setText(myList.getHead());
        holder.textViewDesc.setText("Price:"+myList.getDesc());
        holder.textViewPrice.setText("Offer Price:"+myList.getOfferp());
        holder.textViewDesc.setPaintFlags(holder.textViewDesc.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);;
//st=myList.getStatus();

        ip=myList.getIP();
        pname=myList.getHead();
        price=myList.getDesc();
        offerp=myList.getOfferp();
        pid=myList.getPid();
        uid=myList.getUid();

p=position;


        holder.cardview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//creating a popup menu
                PopupMenu popup = new PopupMenu(mCtx, holder.buttonViewOption);
                //inflating menu from xml resource
                popup.inflate(R.menu.options_menu);
                //adding click listener
                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()) {
                            case R.id.menu1:
                                //handle menu1 click

                                //Toast.makeText(mCtx, pid, Toast.LENGTH_SHORT).show();
//Toast.makeText(mCtx,""+holder.textViewHead.getText(myList.get(position).getHead()),Toast.LENGTH_LONG).show();
                                   addcart(myList.getUid(),myList.getHead(),myList.getOfferp(),myList.getPid());
                                break;
                           /* case R.id.menu2:
                                //handle menu2 click
                                break;
                            case R.id.menu3:
                                //handle menu3 click
                                break;*/
                        }
                        return false;
                    }
                });
                //displaying the popup
                popup.show();
            }
        });
    }


    @Override
    public int getItemCount() {
        return list.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView textViewHead;
        public CardView cardview;
        public TextView textViewDesc;
        public TextView textViewPrice;
        public TextView buttonViewOption;

        public ViewHolder(View itemView) {
            super(itemView);
            cardview = (CardView) itemView.findViewById(R.id.card);
            textViewHead = (TextView) itemView.findViewById(R.id.textViewHead);
            textViewDesc = (TextView) itemView.findViewById(R.id.textViewDesc);
            textViewPrice = (TextView) itemView.findViewById(R.id.textViewp);
            buttonViewOption = (TextView) itemView.findViewById(R.id.textViewOptions);
        }
    }
    //////////////////////////////////////////////addcart/////////////////////////////////////////////////////
    public void addcart(String uid,String pdtname,String price,String pid) {
        String UrlData = "?uid=" + uid+"&pdtname=" + pdtname+"&price=" + price+"&pid=" + pid;



        class Detailss extends AsyncTask<String, Void, String> {


            ProgressDialog progressDialog;


            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog = ProgressDialog.show(mCtx, "Please wait", null, true, true);


            }

            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                progressDialog.dismiss();
                //Toast.makeText(getApplicationContext(), "result"+s, Toast.LENGTH_LONG).show();

                Toast.makeText(mCtx, "Successfully add to Cart", Toast.LENGTH_LONG).show();




            }

            @Override
            protected String doInBackground(String... params) {

                String s = params[0];
                Log.d("result", params[0]);
                BufferedReader bf = null;

                try {
                    URL url = new URL("http://"+ip+"/Qfree_2017/addcart.php" + s);

                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    bf = new BufferedReader(new InputStreamReader(connection.getInputStream()));


                    String result = bf.readLine();
                    return result;


                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }


            }

        }


        Detailss detaisl = new Detailss();
        detaisl.execute(UrlData);


    }

}