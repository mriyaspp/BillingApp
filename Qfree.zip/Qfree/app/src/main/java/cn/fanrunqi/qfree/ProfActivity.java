package cn.fanrunqi.qfree;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;


public class ProfActivity extends AppCompatActivity {
    String details="";
    TextView tname,tph,taddr,temail,tacc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prof);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        details=getIntent().getStringExtra("details");
        tacc=(TextView)findViewById(R.id.txtacc);
        tname=(TextView)findViewById(R.id.txtname);
        taddr=(TextView)findViewById(R.id.txtaddr);
        temail=(TextView)findViewById(R.id.txtemail);
        tph=(TextView)findViewById(R.id.txtphone);


        try {
            JSONArray jarray=new JSONArray(details);
            for(int i=0;i<jarray.length();i++){
                JSONObject json_data=jarray.getJSONObject(i);

                tacc.setText(" "+json_data.getString("account"));
                taddr.setText(" "+json_data.getString("address"));
                tname.setText(" "+json_data.getString("name"));
                temail.setText(" "+json_data.getString("email"));
                tph.setText(" "+json_data.getString("phone"));

                //details+=json_data.getString("longitude");
                // location= json_data.getString("location");

            }
        } catch (Exception e) {        // TODO Auto-generated catch block
            e.printStackTrace();
        }

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fabprof);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(ProfActivity.this,EditProfileActivity.class);
                i.putExtra("details",details);
                startActivity(i);
            }
        });
    }
}
