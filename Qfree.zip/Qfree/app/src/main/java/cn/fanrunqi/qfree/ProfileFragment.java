package cn.fanrunqi.qfree;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;


public class ProfileFragment extends Fragment {

String details="";
    TextView tname,tph,taddr,temail,tacc;
    private OnFragmentInteractionListener mListener;

    public ProfileFragment() {
        // Required empty public constructor
    }


    // TODO: Rename and change types and number of parameters
    public static ProfileFragment newInstance(String param1, String param2) {
        ProfileFragment fragment = new ProfileFragment();

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root_view= inflater.inflate(R.layout.fragment_profile, container, false);

        details=getArguments().getString("details");
        tacc=(TextView)root_view.findViewById(R.id.txtacc);
        tname=(TextView)root_view.findViewById(R.id.txtname);
        taddr=(TextView)root_view.findViewById(R.id.txtaddr);
        temail=(TextView)root_view.findViewById(R.id.txtemail);
        tph=(TextView)root_view.findViewById(R.id.txtphone);


        try {
            JSONArray jarray=new JSONArray(details);
            for(int i=0;i<jarray.length();i++){
                JSONObject json_data=jarray.getJSONObject(i);

                tacc.setText("Account Number:"+json_data.getString("account"));
                taddr.setText("Address :"+json_data.getString("address"));
                tname.setText("Name :"+json_data.getString("name"));
                temail.setText("Email :"+json_data.getString("email"));
                tph.setText("Contact :"+json_data.getString("phone"));

                //details+=json_data.getString("longitude");
                // location= json_data.getString("location");

            }
        } catch (Exception e) {        // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return root_view;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
