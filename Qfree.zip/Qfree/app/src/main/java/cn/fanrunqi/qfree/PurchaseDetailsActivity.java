package cn.fanrunqi.qfree;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Paint;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class PurchaseDetailsActivity extends AppCompatActivity {
SharedPreferences sp;
    String ip="",pid="",offerp="",pname="",price="",uid="";
    TextView tpname,tprice,top,tofferprice;
    Button baddcart;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_purchase_details);
        sp=getSharedPreferences("qfree", Context.MODE_PRIVATE);
        tpname=(TextView)findViewById(R.id.txtpname);
        tprice=(TextView)findViewById(R.id.txtprice);
        tofferprice=(TextView)findViewById(R.id.txtofferprice);
        top=(TextView)findViewById(R.id.txtoff);
        baddcart=(Button)findViewById(R.id.bcart);

        top.setVisibility(View.INVISIBLE);
        tofferprice.setVisibility(View.INVISIBLE);

        pid=getIntent().getStringExtra("pid");

       // Toast.makeText(getApplicationContext(), "result"+pid, Toast.LENGTH_LONG).show();
        if (sp.contains("ip"))
        {
            ip=sp.getString("ip", "");
        }
        if (sp.contains("uid"))
        {
            uid=sp.getString("uid", "");
        }
        getdetails(pid);

        baddcart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addcart(uid,pname,price,pid);
            }
        });
    }
    //////////////////////////////////////////////getdetails/////////////////////////////////////////////////////
    public void getdetails(String pid) {
        String UrlData = "?pid=" + pid;

       // Toast.makeText(getApplicationContext(), "details"+UrlData, Toast.LENGTH_LONG).show();

        class Details extends AsyncTask<String, Void, String> {


            ProgressDialog progressDialog;


            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog = ProgressDialog.show(PurchaseDetailsActivity.this, "Please wait", null, true, true);


            }

            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                progressDialog.dismiss();
                Log.d("result",s);
          //  Toast.makeText(getApplicationContext(), "resultss"+s, Toast.LENGTH_LONG).show();
                if (s != null&& s.equalsIgnoreCase("failed")) {
                    Toast.makeText(getApplicationContext(), "Invalid Product", Toast.LENGTH_LONG).show();

                }
                else{
                    try {
                        JSONArray jarray=new JSONArray(s);
                        for(int i=0;i<jarray.length();i++){
                            JSONObject json_data=jarray.getJSONObject(i);
                            offerp=json_data.getString("offer");
                            if(offerp.equals("1")) {
                                top.setVisibility(View.VISIBLE);
                                tofferprice.setVisibility(View.VISIBLE);
                                pname=json_data.getString("pname");
                                price=json_data.getString("offerprice");
                                tpname.setText(pname);

                                tprice.setText(json_data.getString("price"));
                                tprice.setPaintFlags(tprice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                                tofferprice.setText(json_data.getString("offerprice"));

                            }
                            else{

                                pname=json_data.getString("pname");
                                price=json_data.getString("price");
                                tpname.setText(pname);

                                tprice.setText(price);

                            }

                        }
                    } catch (Exception e) {        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }

            }

            @Override
            protected String doInBackground(String... params) {

                String s = params[0];
                Log.d("result", params[0]);
                BufferedReader bf = null;

                try {
                    URL url = new URL("http://"+ip+"/Qfree_2017/get_pdt_details.php" + s);

                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    bf = new BufferedReader(new InputStreamReader(connection.getInputStream()));


                    String result = bf.readLine();
                    return result;


                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }


            }

        }


        Details detail = new Details();
        detail.execute(UrlData);


    }
    //////////////////////////////////////////////addcart/////////////////////////////////////////////////////
    public void addcart(String uid,String pdtname,String price,String pid) {
        String UrlData = "?uid=" + uid+"&pdtname=" + pdtname+"&price=" + price+"&pid=" + pid;



        class Detailss extends AsyncTask<String, Void, String> {


            ProgressDialog progressDialog;


            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog = ProgressDialog.show(PurchaseDetailsActivity.this, "Please wait", null, true, true);


            }

            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                progressDialog.dismiss();
                //Toast.makeText(getApplicationContext(), "result"+s, Toast.LENGTH_LONG).show();

                    Toast.makeText(getApplicationContext(), "Successfully add to Cart", Toast.LENGTH_LONG).show();




            }

            @Override
            protected String doInBackground(String... params) {

                String s = params[0];
                Log.d("result", params[0]);
                BufferedReader bf = null;

                try {
                    URL url = new URL("http://"+ip+"/Qfree_2017/addcart.php" + s);

                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    bf = new BufferedReader(new InputStreamReader(connection.getInputStream()));


                    String result = bf.readLine();
                    return result;


                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }


            }

        }


        Detailss detaisl = new Detailss();
        detaisl.execute(UrlData);


    }
}
